from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def courses(request):
    return render(request,'courses.html')

def index(request):
    return render(request,'index.html')

def student(request):
    return render(request,'student.html')

def signin(request):
    return render(request,'signin.html')

def videos(request):
    return render(request,'videos.html')




