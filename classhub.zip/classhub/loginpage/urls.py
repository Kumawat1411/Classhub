from django.contrib import admin
from django.urls import path
from django.urls import include
from loginpage import views

urlpatterns = [
     path('', views.index, name='index'),
     path('about/', views.about, name='about'),
     path('contact/', views.contact, name='contact'),
     path('courses/', views.courses, name='courses'),
     path('sigin/', views.signin, name='signin'),
     path('student/', views.student, name='student'),
     path('videos/', views.videos, name='videos'),

]
